package com.example.grinderbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1559;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_746;
import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;

public class GrinderBotClient implements ClientModInitializer {

    // ---- Tunables ----
    private static final int ATTACK_INTERVAL_TICKS = 1;   // 20 ticks/sec ÷ 10 cps
    private static final double ATTACK_RANGE = 3.0;        // blocks, 1.8-style reach
    private static final double SEARCH_RADIUS = 24.0;      // blocks, how far to look for mites
    private static final String GRIND_TOKEN_NAME = "Grind Token";
    private static final String GIFT_TARGET = "shivanshu7";
    private static final int TOKEN_THRESHOLD = 15;
    private static final int GIFT_MENU_TOKEN_SLOT = 11;

    private static final int WAIT_GOTO_START_TIMEOUT = 40;
    private static final int WAIT_MENU_TIMEOUT = 100;

    // ---- State machine ----
    private enum State {
        IDLE,
        WAIT_FOR_GOTO_START, WAIT_FOR_ARRIVAL,
        ACTIVE,
        SEND_GIFT, WAIT_GIFT_MENU, CLICK_TOKEN, CLOSE_GIFT_MENU,
        WAIT_CONFIRM_MENU, CLICK_CONFIRM
    }
    private State state = State.IDLE;

    private boolean running = false; // master on/off switch

    private int actionTickCounter = 0;
    private int attackTickCounter = 0;

    private volatile boolean giftScreenOpened = false;
    private volatile boolean confirmScreenOpened = false;

    @Override
    public void onInitializeClient() {

        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.toLowerCase().startsWith("%grind")) {
                return true; // not ours, let it through untouched
            }

            String command = message.substring(1).trim(); // "grind ..."
            String[] parts = command.split("\\s+");

            if (parts.length == 4) {
                // %grind x y z -> initial move to grinder area, then auto-start
                String coords = parts[1] + " " + parts[2] + " " + parts[3];
                notify("§bHeading to grinder at " + coords);
                getBaritone().getPathingBehavior().cancelEverything();
                getBaritone().getCommandManager().execute("stop");
                getBaritone().getCommandManager().execute("goto " + coords);
                running = true;
                actionTickCounter = 0;
                state = State.WAIT_FOR_GOTO_START;

            } else if (parts.length == 2 && parts[1].equalsIgnoreCase("stop")) {
                running = false;
                getBaritone().getPathingBehavior().cancelEverything();
                getBaritone().getCommandManager().execute("stop");
                notify("§cGrinding stopped");

            } else if (parts.length == 2 && parts[1].equalsIgnoreCase("start")) {
                running = true;
                if (state == State.IDLE) {
                    state = State.ACTIVE; // resume from current position, auto-seeks target
                }
                notify("§aGrinding resumed");

            } else {
                notify("§cUsage: %grind x y z | %grind start | %grind stop");
            }

            return false; // cancel actual chat send in all cases
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof class_465) {
                if (state == State.WAIT_GIFT_MENU) {
                    giftScreenOpened = true;
                } else if (state == State.WAIT_CONFIRM_MENU) {
                    confirmScreenOpened = true;
                }
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        switch (state) {
            case IDLE:
                break; // waiting for a %grind command

            case WAIT_FOR_GOTO_START:
                actionTickCounter++;
                if (isBaritoneActive()) {
                    state = State.WAIT_FOR_ARRIVAL;
                } else if (actionTickCounter > WAIT_GOTO_START_TIMEOUT) {
                    notify("§cGoto never started — check coordinates");
                    state = State.IDLE;
                }
                break;

            case WAIT_FOR_ARRIVAL:
                if (!isBaritoneActive()) {
                    notify("§aArrived — starting auto-grind");
                    attackTickCounter = 0;
                    state = State.ACTIVE;
                }
                break;

            case ACTIVE:
                doActiveTick(client);
                break;

            case SEND_GIFT:
                sendCommand(client, "gift " + GIFT_TARGET);
                giftScreenOpened = false;
                actionTickCounter = 0;
                state = State.WAIT_GIFT_MENU;
                break;

            case WAIT_GIFT_MENU:
                actionTickCounter++;
                if (giftScreenOpened) {
                    state = State.CLICK_TOKEN;
                } else if (actionTickCounter > WAIT_MENU_TIMEOUT) {
                    notify("§cGift menu never opened — resuming grind");
                    state = State.ACTIVE;
                }
                break;

            case CLICK_TOKEN:
                clickGiftTokenSlot(client);
                actionTickCounter = 0;
                state = State.CLOSE_GIFT_MENU;
                break;

            case CLOSE_GIFT_MENU:
                if (client.field_1755 != null) {
                    client.field_1724.method_7346();
                }
                confirmScreenOpened = false;
                actionTickCounter = 0;
                state = State.WAIT_CONFIRM_MENU;
                break;

            case WAIT_CONFIRM_MENU:
                actionTickCounter++;
                if (confirmScreenOpened) {
                    state = State.CLICK_CONFIRM;
                } else if (actionTickCounter > 60) {
                    state = State.ACTIVE;
                }
                break;

            case CLICK_CONFIRM:
                clickSlotZero(client);
                if (client.field_1755 != null) {
                    client.field_1724.method_7346();
                }
                notify("§aGifted token — resuming grind");
                attackTickCounter = 0;
                state = State.ACTIVE;
                break;
        }
    }

    private void doActiveTick(class_310 client) {
        class_746 player = client.field_1724;

        // Master switch check: if stopped, make sure we're not still moving, then idle
        if (!running) {
            if (isBaritoneActive()) {
                getBaritone().getPathingBehavior().cancelEverything();
                getBaritone().getCommandManager().execute("stop");
            }
            return;
        }

         // 1. Grind Tokens take priority once we've stacked up enough of them
int tokenCount = countGrindTokens(player);
if (tokenCount >= TOKEN_THRESHOLD) {
    notify("§e" + tokenCount + " Grind Tokens collected — pausing to gift");
    if (isBaritoneActive()) {
        getBaritone().getPathingBehavior().cancelEverything();
    }
    state = State.SEND_GIFT;
    return;
}

        // 2. Find nearest endermite within search radius
        class_238 searchBox = player.method_5829().method_1014(SEARCH_RADIUS);
        var candidates = client.field_1687.method_18467(class_1559.class, searchBox);

        class_1559 nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (class_1559 mite : candidates) {
            double distSq = mite.method_5858(player);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = mite;
            }
        }

        if (nearest == null) {
            // nothing to fight right now
            return;
        }

        double distance = Math.sqrt(nearestDistSq);
        faceEntity(player, nearest);

        if (distance > ATTACK_RANGE) {
            // out of range -> path to it, but don't spam goto every tick
            if (!isBaritoneActive()) {
                class_2338 pos = nearest.method_24515();
                getBaritone().getCommandManager().execute(
                        "goto " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260());
            }
            return;
        }

        // in range -> stop any movement, then attack at 10 cps
        if (isBaritoneActive()) {
            getBaritone().getPathingBehavior().cancelEverything();
        }

        attackTickCounter++;
        if (attackTickCounter >= ATTACK_INTERVAL_TICKS) {
            attackTickCounter = 0;
            client.field_1761.method_2918(player, nearest);
            player.method_6104(class_1268.field_5808);
        }
    }

    private void faceEntity(class_746 player, class_1559 target) {
        double dx = target.method_23317() - player.method_23317();
        double dy = (target.method_23318() + target.method_5751() * 0.5)
                - (player.method_23318() + player.method_5751());
        double dz = target.method_23321() - player.method_23321();

        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontalDist));

        player.method_36456(yaw);
        player.method_36457(pitch);
    }

    private int countGrindTokens(class_746 player) {
    var inventory = player.method_31548();
    int count = 0;
    for (int i = 0; i < 36; i++) {
        class_1799 stack = inventory.method_5438(i);
        if (!stack.method_7960() && isGrindToken(stack)) {
            count += stack.method_7947();
        }
    }
    return count;
}

    private boolean isGrindToken(class_1799 stack) {
        class_2561 name = stack.method_7964();
        return name != null && name.getString().contains(GRIND_TOKEN_NAME);
    }

private void clickGiftTokenSlot(class_310 client) {
    if (!(client.field_1755 instanceof class_465<?> screen)) return;
    class_1703 menu = screen.method_17577();
    client.field_1761.method_2906(
            menu.field_7763, GIFT_MENU_TOKEN_SLOT, 0, class_1713.field_7790, client.field_1724);
}

    private void clickSlotZero(class_310 client) {
        if (!(client.field_1755 instanceof class_465<?> screen)) return;
        class_1703 menu = screen.method_17577();
        client.field_1761.method_2906(
                menu.field_7763, 0, 0, class_1713.field_7790, client.field_1724);
    }

    private void sendCommand(class_310 client, String command) {
        client.field_1724.field_3944.method_45730(command);
    }

    private boolean isBaritoneActive() {
        IBaritone baritone = getBaritone();
        return baritone.getPathingBehavior().isPathing()
                || baritone.getPathingBehavior().hasPath();
    }

    private IBaritone getBaritone() {
        return BaritoneAPI.getProvider().getPrimaryBaritone();
    }

    private void notify(String msg) {
        class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_43470(msg));
    }
}
