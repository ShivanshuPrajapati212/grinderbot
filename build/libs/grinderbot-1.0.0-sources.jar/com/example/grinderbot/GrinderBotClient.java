package com.example.grinderbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1559;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_465;
import net.minecraft.class_746;
import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;

public class GrinderBotClient implements ClientModInitializer {

    // ---- Tunables ----
    private static final int ATTACK_INTERVAL_TICKS = 2; // 20 ticks/sec ÷ 10 cps = every 2 ticks
    private static final String GRIND_TOKEN_NAME = "Grind Token";
    private static final String GIFT_TARGET = "shivanshu6";

    private static final int WAIT_GOTO_START_TIMEOUT = 40;
    private static final int WAIT_MENU_TIMEOUT = 100;

    // ---- State machine ----
    private enum State {
        IDLE,
        WAIT_FOR_GOTO_START, WAIT_FOR_ARRIVAL,
        KILLING,
        SEND_GIFT, WAIT_GIFT_MENU, CLICK_TOKEN, CLOSE_GIFT_MENU,
        WAIT_CONFIRM_MENU, CLICK_CONFIRM
    }
    private State state = State.IDLE;

    private int actionTickCounter = 0;
    private int attackTickCounter = 0;

    private volatile boolean giftScreenOpened = false;
    private volatile boolean confirmScreenOpened = false;

    private int tokenSlotIndex = -1; // slot found holding the Grind Token, set when detected

    @Override
    public void onInitializeClient() {

        // Intercept "$grind x y z" -> goto coords, then auto-start killing loop on arrival
        // Other "$..." messages still pass straight to Baritone, same as your mining mod
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (message.startsWith("$")) {
                String command = message.substring(1).trim();

                if (command.toLowerCase().startsWith("grind ")) {
                    String[] parts = command.split("\\s+");
                    if (parts.length == 4) {
                        String coords = parts[1] + " " + parts[2] + " " + parts[3];
                        notify("§bHeading to grinder at " + coords);
                        getBaritone().getPathingBehavior().cancelEverything();
                        getBaritone().getCommandManager().execute("stop");
                        getBaritone().getCommandManager().execute("goto " + coords);
                        actionTickCounter = 0;
                        state = State.WAIT_FOR_GOTO_START;
                    } else {
                        notify("§cUsage: $grind x y z");
                    }
                } else if (!command.isEmpty()) {
                    getBaritone().getCommandManager().execute(command);
                }
                return false; // cancel actual chat send either way
            }
            return true;
        });

        // Detect when the gift menu / confirmation menu opens
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof class_465) {
                if (state == State.WAIT_GIFT_MENU) {
                    giftScreenOpened = true;
                } else if (state == State.WAIT_CONFIRM_MENU) {
                    confirmScreenOpened = true;
                }
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(class_310 client) {
        if (client.field_1724 == null) return;

        switch (state) {
            case IDLE:
                // nothing happening until "$grind x y z" is sent
                break;

            case WAIT_FOR_GOTO_START:
                actionTickCounter++;
                if (isBaritoneActive()) {
                    state = State.WAIT_FOR_ARRIVAL;
                } else if (actionTickCounter > WAIT_GOTO_START_TIMEOUT) {
                    notify("§cGoto never started — check coordinates");
                    state = State.IDLE;
                }
                break;

            case WAIT_FOR_ARRIVAL:
                if (!isBaritoneActive()) {
                    notify("§aArrived — starting kill loop");
                    attackTickCounter = 0;
                    state = State.KILLING;
                }
                break;

            case KILLING:
                doKillingTick(client);
                break;

            case SEND_GIFT:
                sendCommand(client, "gift " + GIFT_TARGET);
                giftScreenOpened = false;
                actionTickCounter = 0;
                state = State.WAIT_GIFT_MENU;
                break;

            case WAIT_GIFT_MENU:
                actionTickCounter++;
                if (giftScreenOpened) {
                    state = State.CLICK_TOKEN;
                } else if (actionTickCounter > WAIT_MENU_TIMEOUT) {
                    notify("§cGift menu never opened — resuming kill loop");
                    state = State.KILLING;
                }
                break;

            case CLICK_TOKEN:
                clickTokenSlot(client);
                actionTickCounter = 0;
                state = State.CLOSE_GIFT_MENU;
                break;

            case CLOSE_GIFT_MENU:
                if (client.field_1755 != null) {
                    client.field_1724.method_7346();
                }
                confirmScreenOpened = false;
                actionTickCounter = 0;
                state = State.WAIT_CONFIRM_MENU;
                break;

            case WAIT_CONFIRM_MENU:
                actionTickCounter++;
                if (confirmScreenOpened) {
                    state = State.CLICK_CONFIRM;
                } else if (actionTickCounter > 60) {
                    // no confirmation appeared, just resume killing
                    state = State.KILLING;
                }
                break;

            case CLICK_CONFIRM:
                clickSlotZero(client);
                if (client.field_1755 != null) {
                    client.field_1724.method_7346();
                }
                notify("§aGifted token — resuming kill loop");
                attackTickCounter = 0;
                state = State.KILLING;
                break;
        }
    }

    private void doKillingTick(class_310 client) {
        // 1. Check inventory for a Grind Token first — pause killing if found
        int slot = findGrindTokenSlot(client.field_1724);
        if (slot != -1) {
            tokenSlotIndex = slot;
            notify("§eGrind Token found — pausing to gift");
            state = State.SEND_GIFT;
            return;
        }

        // 2. Attack loop at 10 cps
        attackTickCounter++;
        if (attackTickCounter < ATTACK_INTERVAL_TICKS) return;
        attackTickCounter = 0;

        class_239 hit = client.field_1765;
        if (hit instanceof class_3966 entityHit) {
            class_1297 target = entityHit.method_17782();
            if (target instanceof class_1559) {
                client.field_1761.method_2918(client.field_1724, target);
                client.field_1724.method_6104(class_1268.field_5808);
            }
        }
    }

    private int findGrindTokenSlot(class_746 player) {
        var inventory = player.method_31548();
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && isGrindToken(stack)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isGrindToken(class_1799 stack) {
        class_2561 name = stack.method_7964();
        return name != null && name.getString().contains(GRIND_TOKEN_NAME);
    }

    private void clickTokenSlot(class_310 client) {
        if (!(client.field_1755 instanceof class_465<?> screen)) return;
        class_1703 menu = screen.method_17577();
        class_746 player = client.field_1724;

        // Find the slot in the OPEN MENU (not raw inventory index) that holds
        // the Grind Token, since menu slot indices differ from inventory indices
        // once wrapped in a container screen.
        for (var slot : menu.field_7761) {
            if (slot.field_7871 == player.method_31548() && !slot.method_7677().method_7960()
                    && isGrindToken(slot.method_7677())) {
                client.field_1761.method_2906(
                        menu.field_7763, slot.field_7874, 0, class_1713.field_7790, player);
                return;
            }
        }
        notify("§cCouldn't find token slot in gift menu");
    }

    private void clickSlotZero(class_310 client) {
        if (!(client.field_1755 instanceof class_465<?> screen)) return;
        class_1703 menu = screen.method_17577();
        client.field_1761.method_2906(
                menu.field_7763, 0, 0, class_1713.field_7790, client.field_1724);
    }

    private void sendCommand(class_310 client, String command) {
        client.field_1724.field_3944.method_45730(command);
    }

    private boolean isBaritoneActive() {
        IBaritone baritone = getBaritone();
        return baritone.getPathingBehavior().isPathing()
                || baritone.getPathingBehavior().hasPath();
    }

    private IBaritone getBaritone() {
        return BaritoneAPI.getProvider().getPrimaryBaritone();
    }

    private void notify(String msg) {
        class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_43470(msg));
    }
}
